package com.cg.obs.controller;

import java.io.IOException;

import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;
import com.cg.obs.service.UserServiceImpl;


@WebServlet(urlPatterns={"/BankingApplicationController","/Login","/GetMiniTransactions","/GetDetailedTransactions","/UpdateProfile",
		"/UpdateProfileSuccess","/FundTransfer","/AddPayee","/ProcessTransaction"})
public class BankingApplicationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	IUserService userService;
    public BankingApplicationController() {
        
    	userService=new UserServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path=request.getServletPath();
		String url="";
		
		switch(path)
		{
		case "/Login":
		{
			String id=request.getParameter("username");
			String password=request.getParameter("password");
			
			int hitCounter=0;
			Users user=userService.getUser(Integer.parseInt(id));
			System.out.println(user);
			if(user!=null)
				{
				if(user.getLockStatus()!="L")
					
				{
					
					if(password.equalsIgnoreCase(user.getLoginPassword()))
					{
						System.out.println(user.getLoginPassword());
						url="Projects/index.jsp";
						
						/*request.setAttribute("userid", user.getUserId());
						request.setAttribute("accountno", user.getAccountId());*/
						HttpSession session=request.getSession();
						session.setAttribute("accountno", user.getAccountId());
						
						session.setAttribute("userid", id);
						}
					else
					{
						hitCounter++;
						System.out.println(hitCounter);
						if(hitCounter==3)
						{
							userService.updateLockStatus(user.getUserId());
							System.out.println("Your Account Locked");
							
							throw new UserException("Your Account is locked");
						}
					url="#"; 
					}
				}
				else
				{
					System.out.println("Wrong Password"+hitCounter);
				}
				}
			else
			{
				throw new UserException("No User Exists.....");
			}
		
			break;
		}	
		case "/GetMiniTransactions":
		{	
			HttpSession session=request.getSession(false);
			Long accountno=(Long)session.getAttribute("accountno");
			System.out.println("In getminitrans accountno:"+accountno);
			//Long accountno=Long.parseLong(accountid);
			List<Transactions> miniTransList=userService.getMiniTransactions(accountno);
			System.out.println("miniTransList:"+miniTransList);
			request.setAttribute("miniTransactionList", miniTransList);
			url="Projects/pages/MiniTransactions.jsp";
			break;
		}
		case "/GetDetailedTransactions":
		{	
			HttpSession session=request.getSession(false);
			Long accountno=(Long)session.getAttribute("accountno");
			System.out.println("In getdetailedtrans accountno:"+accountno);
			Date fromDate=Date.valueOf(request.getParameter("fromDate"));
			Date toDate=Date.valueOf(request.getParameter("toDate"));
			
			List<Transactions> detailedTransList=userService.getDetailedTransactions(accountno,fromDate,toDate);
			System.out.println("detailedTransList:"+detailedTransList);
			request.setAttribute("detailedTransactionList", detailedTransList);
			url="Projects/pages/DetailedTransactions.jsp";
			break;
		}
		
		case "/UpdateProfile":
		{
			Customer customer=null;
			
				HttpSession session=request.getSession(false);
				Long accountno=(Long)session.getAttribute("accountno");
				int customerid=(Integer)userService.getCustomerId(accountno);
				customer=userService.getCustomer(customerid);
				request.setAttribute("customer_ID", customer.getCustomer_ID());
				request.setAttribute("customer_Name", customer.getCustomer_Name());
				request.setAttribute("email", customer.getEmail());
				request.setAttribute("mobileNo", customer.getMobileNo());
				request.setAttribute("address", customer.getAddress());
				request.setAttribute("pancard", customer.getPancard());
				url="Projects/pages/UpdateProfile.jsp";
				break;
		}
		
		case "/UpdateProfileSuccess":
		{
			System.out.println("in update sucess");
			int customerId=Integer.parseInt(request.getParameter("customerid"));
			String cname=request.getParameter("customerName");
			String email=request.getParameter("email");
			Long mobileno=Long.parseLong(request.getParameter("mobileNo"));
			String address=request.getParameter("address");
			String pancard=request.getParameter("pancard");
	
		
			Customer customer=new Customer();
			customer.setCustomer_ID(customerId);
			customer.setCustomer_Name(cname);
			customer.setEmail(email);
			customer.setMobileNo(mobileno);
			customer.setAddress(address);
			customer.setPancard(pancard);
		
			System.out.println("in update sucess"+customer);
			userService.updateCustomerDetails(customer);
			System.out.println("update sucess");
			url="Projects/pages/UpdateProfileSuccess.jsp";
			break;
			
		}
		
		case "/FundTransfer":
		{
			HttpSession session=request.getSession(false);
			Long accountno=(Long)session.getAttribute("accountno");
			List<Payee> payeeList=userService.getPayee(accountno);
			request.setAttribute("payeeList", payeeList);
			url="Projects/pages/FundTransfer.jsp";
			break;
		}
		case "/AddPayee":
		{
			HttpSession session=request.getSession(false);
			Long accountno=(Long)session.getAttribute("accountno");
			
			Long payeeAccountNo=Long.parseLong(request.getParameter("txtAccountNo"));
			String payeeNickname=request.getParameter("txtNickName");
			Payee payee=new Payee();
			payee.setAccountno(accountno);
			payee.setPayeeAccountNo(payeeAccountNo);
			payee.setNickName(payeeNickname);
			userService.insertPayee(payee);
			
			break;
		}
		case "/ProcessTransaction":
		{
			Users user=null;
			
			double transactionAmount=Double.parseDouble(request.getParameter("txtAmount"));
			String password=request.getParameter("txtPwd");
			
			HttpSession session=request.getSession(false);
			Long accountno=(Long)session.getAttribute("accountno");
			int customerid=(Integer)userService.getCustomerId(accountno);
			
			
			int userid=(int)session.getAttribute("userid");
			
			user=userService.getUser(customerid);
			AccountMaster account=userService.getAccount(accountno);
			
			if(user.getTransPassword()==password)
			{
				if(account.getAccountBalance()>transactionAmount)
				{
					
					
					
					
				url="Projects/pages/FTSuccess.jsp";
				}
				else
				{
					url="Projects/pages/ErrorPage.jsp";				}
			}
			else
			{
				url="Projects/pages/ErrorPage.jsp";
			}
			break;
		}
		
		
		}
		
		
		
		
		
		
		
		
		
		
		
				
			RequestDispatcher rd=request.getRequestDispatcher(url);
			rd.forward(request, response);
			
			
			
	}
	
		
		
		
}


