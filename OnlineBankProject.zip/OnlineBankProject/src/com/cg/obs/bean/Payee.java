package com.cg.obs.bean;

public class Payee {

	private int payeeid;
	private Long payeeAccountNo;
	private long accountno;
	private String nickName;
	public Payee(int payeeid, Long payeeAccountNo, long accountno,
			String nickName) {
		super();
		this.payeeid = payeeid;
		this.payeeAccountNo = payeeAccountNo;
		this.accountno = accountno;
		this.nickName = nickName;
	}
	
	public Payee() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Payee [payeeid=" + payeeid + ", payeeAccountNo="
				+ payeeAccountNo + ", accountno=" + accountno + ", nickName="
				+ nickName + "]";
	}

	public int getPayeeid() {
		return payeeid;
	}

	public void setPayeeid(int payeeid) {
		this.payeeid = payeeid;
	}

	public Long getPayeeAccountNo() {
		return payeeAccountNo;
	}

	public void setPayeeAccountNo(Long payeeAccountNo) {
		this.payeeAccountNo = payeeAccountNo;
	}

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + payeeid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payee other = (Payee) obj;
		if (payeeid != other.payeeid)
			return false;
		return true;
	}
	
}
