package com.cg.obs.dao;

import com.cg.obs.bean.Admin;
import com.cg.obs.exception.UserException;

public interface IAdminDao {

	public Admin getAdmin(String id) throws UserException;
}
